This folder contains audios and a plot of their spectrograms (Figure 7 in the appendix B). 
The audio names are in the format of `<row number>_<column number>_<novelty lebel>__<speaker id>__<utterance id>.wav`. 
- The row number and column number indicate the position of the audio's spectrogram in the plot. 
- The novelty labels are 'O' (original), 'SS' (same speaker), 'NS' (new speaker) and 'NC' (new content) as described in the paper. 
- The speaker id indicates which speaker the speech is spoken by in the case of 'O' or is converted to in the case of 'SS', 'NS' and 'NC'. 
- The utterance id can be used to find the original audio file and transcripts in the LibriSpeech dataset.